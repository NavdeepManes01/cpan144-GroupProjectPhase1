import { useState } from 'react';
import styles from './Weather.module.css';

export default function Weather() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchWeather = async (e) => {
    e.preventDefault();
    if (!city.trim()) return;

    setLoading(true);
    setError('');
    
    try {
      const response = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
      const data = await response.json();
      
      if (response.ok) {
        setWeather(data);
      } else {
        setError(data.message || 'Failed to fetch weather');
      }
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <h1>Weather Broadcast</h1>
      
      <form onSubmit={fetchWeather} className={styles.form}>
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="Enter city name"
          className={styles.input}
        />
        <button 
          type="submit" 
          className={styles.button}
          disabled={loading}
        >
          {loading ? 'Loading...' : 'Get Weather'}
        </button>
      </form>

      {error && <p className={styles.error}>{error}</p>}

      {weather && (
        <div className={styles.weatherCard}>
          <h2>{weather.location.name}, {weather.location.country}</h2>
          <div className={styles.weatherDetails}>
            <img src={weather.current.condition.icon} alt={weather.current.condition.text} />
            <p><strong>Condition:</strong> {weather.current.condition.text}</p>
            <p><strong>Temperature:</strong> {weather.current.temp_c}°C</p>
            <p><strong>Humidity:</strong> {weather.current.humidity}%</p>
            <p><strong>Wind:</strong> {weather.current.wind_kph} km/h</p>
          </div>
        </div>
      )}
    </div>
  );
}