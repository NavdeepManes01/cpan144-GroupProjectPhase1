import { useState } from 'react';
import styles from './Calculator.module.css';

export default function Calculator() {
  const [display, setDisplay] = useState('0');
  const [history, setHistory] = useState([]);

  const handleButtonClick = (value) => {
    if (display === '0' && value !== '.') {
      setDisplay(value);
    } else {
      setDisplay(display + value);
    }
  };

  const calculate = () => {
    try {
      const result = eval(display).toString();
      setHistory([...history, `${display} = ${result}`]);
      setDisplay(result);
    } catch {
      setDisplay('Error');
    }
  };

  const clearDisplay = () => {
    setDisplay('0');
  };

  const deleteLast = () => {
    setDisplay(display.length > 1 ? display.slice(0, -1) : '0');
  };

  return (
    <div className={styles.calculator}>
      <input
        type="text"
        value={display}
        disabled
        className={styles.display}
      />
      
      <div className={styles.buttons}>
        <button onClick={clearDisplay} className={styles.functionButton}>C</button>
        <button onClick={deleteLast} className={styles.functionButton}>DEL</button>
        <button onClick={() => handleButtonClick('/')} className={styles.operator}>/</button>
        
        <button onClick={() => handleButtonClick('7')}>7</button>
        <button onClick={() => handleButtonClick('8')}>8</button>
        <button onClick={() => handleButtonClick('9')}>9</button>
        <button onClick={() => handleButtonClick('*')} className={styles.operator}>*</button>
        
        <button onClick={() => handleButtonClick('4')}>4</button>
        <button onClick={() => handleButtonClick('5')}>5</button>
        <button onClick={() => handleButtonClick('6')}>6</button>
        <button onClick={() => handleButtonClick('-')} className={styles.operator}>-</button>
        
        <button onClick={() => handleButtonClick('1')}>1</button>
        <button onClick={() => handleButtonClick('2')}>2</button>
        <button onClick={() => handleButtonClick('3')}>3</button>
        <button onClick={() => handleButtonClick('+')} className={styles.operator}>+</button>
        
        <button onClick={() => handleButtonClick('0')} className={styles.zero}>0</button>
        <button onClick={() => handleButtonClick('.')}>.</button>
        <button onClick={calculate} className={styles.equals}>=</button>
      </div>
      
      {history.length > 0 && (
        <div className={styles.history}>
          <h3>History</h3>
          <ul>
            {history.slice().reverse().map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}