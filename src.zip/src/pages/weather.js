export default async function handler(req, res) {
  const { city } = req.query;
  const apiKey = process.env.WEATHER_API_KEY;

  if (!city) {
    return res.status(400).json({ message: 'City parameter is required' });
  }

  try {
    const response = await fetch(
      `http://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city}`
    );
    const data = await response.json();
    
    if (data.error) {
      return res.status(400).json({ message: data.error.message });
    }
    
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch weather data' });
  }
}