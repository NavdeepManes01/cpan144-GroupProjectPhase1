import Layout from '../components/Layout';
import HomeContent from '../components/HomePage';

export default function Home() {
  return (
    <Layout>
      <HomeContent />
    </Layout>
  );
}